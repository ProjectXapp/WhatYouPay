//
//  SWTextField.swift
//  SWCombox
//
//  Created by Owner on 2016-04-09.
//  Copyright © 2016 owner. All rights reserved.
//

import UIKit




class SWTextFieldView: UIViewController {


    
    
    
    var delegate:SWComboxViewDelegate!
    var supView:UIView!
    
    var tableView:UITableView!
    var list = []
    var helper:SWComboxCommonHelper!
    var defaultIndex = 0
    var isOpen = false

    
    
   
}
