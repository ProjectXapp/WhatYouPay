//
//  SWComboxTitleHelper.swift
//  AuntFood
//
//  Created by owner on 7/4/2016.
//  Copyright (c) 2016 shou. All rights reserved.
//

import UIKit

protocol SWComboxCommonHelper {
    
    func loadCurrentView(contentView:UIView, data: AnyObject)
    
    func setCurrentView(data: AnyObject)
    
    func getCurrentCell(tableView: UITableView, data: AnyObject) -> UITableViewCell
    
    func getCurrentTitle() -> String
    
}



class SWComboxTitleHelper: SWComboxCommonHelper {
    
    var comboxView:SWComboxTitle!
    
    func loadCurrentView(contentView:UIView, data: AnyObject)
    {
        comboxView = UIView.loadInstanceFromNibNamedToContainner(contentView)
        comboxView.bindTitle(data)
    }
    
    func setCurrentView(data: AnyObject){
        comboxView.bindTitle(data)
    }
    
    func getCurrentCell(tableView: UITableView, data: AnyObject) -> UITableViewCell {
        var cellFrame = comboxView.frame
        cellFrame.size.width = tableView.frame.size.width
        
        let cell = UITableViewCell()
        cell.frame = cellFrame
        
        var comboxV : SWComboxTitle
        comboxV = UIView.loadInstanceFromNibNamedToContainner(cell)!
        comboxV.bindTitle(data)
        return cell
    }
    
    func getCurrentTitle() -> String {
        return self.comboxView.name.text!
    }
    
}

class SWComboxTaxRateHelper: SWComboxCommonHelper {
    
    var comboxView:SWComboxTaxRate!
    
    func loadCurrentView(contentView:UIView, data: AnyObject)
    {
        comboxView = UIView.loadInstanceFromNibNamedToContainner(contentView)
        comboxView.bindTaxRate(data as! SWTaxRate)
    }
    
    func setCurrentView(data: AnyObject){
        comboxView.bindTaxRate(data as! SWTaxRate)
    }
    
    func getCurrentCell(tableView: UITableView, data: AnyObject) -> UITableViewCell {
        var cellFrame = comboxView.frame
        cellFrame.size.width = tableView.frame.size.width
        
        let cell = UITableViewCell()
        cell.frame = cellFrame
        
        var comboxV : SWComboxTaxRate
        comboxV = UIView.loadInstanceFromNibNamedToContainner(cell)!
        comboxV.bindTaxRate(data as! SWTaxRate)
        return cell
    }
    
    func getCurrentTitle() -> String {
        return self.comboxView.rate.text!
    }
}





