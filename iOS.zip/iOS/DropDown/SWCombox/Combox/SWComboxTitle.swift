//
//  SWComboxTitleView.swift
//  AuntFood
//
//  Created by owner on 7/4/2016.
//  Copyright (c) 2016 shou. All rights reserved.
//

import UIKit

class SWComboxTitle: UIView {

    @IBOutlet weak var name: UILabel!

    func bindTitle(title: AnyObject)
    {
        name.text = title as? String
    }

}
