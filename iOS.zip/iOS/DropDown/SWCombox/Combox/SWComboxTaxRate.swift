//
//  SWComboboxTaxRate.swift
//  SWCombox
//
//  Created by Owner on 2016-04-08.
//  Copyright © 2016. All rights reserved.
//

import UIKit

class SWTaxRate:NSObject {
    var rate:String!
    var image:UIImage!
}


class SWComboxTaxRate: UIView {
    
    @IBOutlet weak var icon: UIImageView!
    
    @IBOutlet weak var rate: UILabel!
    
    
    func bindTaxRate(taxrate: SWTaxRate)
    {
        bindImage(taxrate.image, title: taxrate.rate)
    }
    
    func bindImage(image: UIImage, title: String)
    {
        icon.image = image
        rate.text = title
    }
}