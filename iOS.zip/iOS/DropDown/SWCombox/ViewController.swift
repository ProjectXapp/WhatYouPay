//
//  ViewController.swift
//  SWCombox
//
//  Created by owner on 08/03/16.
//  Copyright (c) 2016 owner. All rights reserved.
//

import UIKit

class ViewController: UIViewController, SWComboxViewDelegate {

    //@IBOutlet weak var containner1: UIView!
    
    @IBOutlet weak var containner2: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        //setupCombox()
        setupComboxWithImageAndTaxRate()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
  /*  func setupCombox()
    {
        var helper: SWComboxTitleHelper
        helper = SWComboxTitleHelper()
        
        let list = ["good", "middle", "bad"]
        var comboxView:SWComboxView
        comboxView = SWComboxView.loadInstanceFromNibNamedToContainner(self.containner1)!
        comboxView.bindData(list, comboxHelper: helper, seletedIndex: 1, comboxDelegate: self, containnerView: self.view)
    } */
    
    func setupComboxWithImageAndTaxRate(){
        let helper = SWComboxTaxRateHelper()
        
        let rate1 = SWTaxRate()
        rate1.rate = "13%"
        rate1.image = UIImage(named: "general.png")
        
        let rate2 = SWTaxRate()
        rate2.rate = "6%"
        rate2.image = UIImage(named: "baby.png")
        
        let rate3 = SWTaxRate()
        rate3.rate = "5%"
        rate3.image = UIImage(named: "book.png")
        
        let list = [rate1, rate2, rate3]
        
        
        
        var comboxView:SWComboxView
        comboxView = SWComboxView.loadInstanceFromNibNamedToContainner(self.containner2)!
        comboxView.bindData(list, comboxHelper: helper, seletedIndex: 1, comboxDelegate: self, containnerView: self.view)
    }
    
    
    
    //MARK: delegate
    func selectedAtIndex(index:Int, withCombox: SWComboxView)
    {
    }
    func tapComboxToOpenTable(combox: SWComboxView)
    {
        
    }

}

